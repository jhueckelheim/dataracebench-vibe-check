#!/bin/bash

# Script to fix common C-to-Go translation issues
# This script will process all DRB*.go files in the current directory

echo "Starting C-to-Go translation fixes..."

for file in DRB*.go; do
    if [[ -f "$file" ]]; then
        echo "Processing $file..."
        
        # Create a temporary file
        temp_file=$(mktemp)
        
        # Step 1: Extract license header (everything before the line containing "package main")
        license_lines=$(grep -n "package main" "$file" | head -1 | cut -d: -f1)
        if [[ -n "$license_lines" ]]; then
            # Extract license header (excluding the misplaced "package main" line)
            head -n $((license_lines - 1)) "$file" > "$temp_file"
            
            # Add proper package declaration and imports
            echo "" >> "$temp_file"
            echo "package main" >> "$temp_file"
            echo "" >> "$temp_file"
            echo "import (" >> "$temp_file"
            echo "    \"fmt\"" >> "$temp_file"
            echo "    \"sync\"" >> "$temp_file"
            echo ")" >> "$temp_file"
            echo "" >> "$temp_file"
            
            # Extract the actual code (everything after the misplaced "package main")
            tail -n +$((license_lines + 1)) "$file" >> "$temp_file"
        else
            # If no "package main" found, just add it at the top
            echo "package main" > "$temp_file"
            echo "" >> "$temp_file"
            echo "import (" >> "$temp_file"
            echo "    \"fmt\"" >> "$temp_file"
            echo "    \"sync\"" >> "$temp_file"
            echo ")" >> "$temp_file"
            echo "" >> "$temp_file"
            cat "$file" >> "$temp_file"
        fi
        
        # Step 2: Fix common C-style syntax
        sed -i '' \
            -e 's/var main (void)/func main()/' \
            -e 's/static void /func /' \
            -e 's/return 0//' \
            -e 's/printf(/fmt.Printf(/' \
            "$temp_file"
        
        # Replace the original file with the fixed version
        mv "$temp_file" "$file"
        
        echo "Fixed $file"
    fi
done

echo "Basic fixes complete. Now testing compilation..."

# Test if files compile
success_count=0
total_count=0

for file in DRB*.go; do
    if [[ -f "$file" ]]; then
        total_count=$((total_count + 1))
        echo -n "Testing $file... "
        if go build "$file" 2>/dev/null; then
            echo "OK"
            success_count=$((success_count + 1))
            # Clean up the compiled binary
            rm -f "${file%.go}"
        else
            echo "NEEDS MANUAL FIX"
        fi
    fi
done

echo "Summary: $success_count/$total_count files compile successfully" 