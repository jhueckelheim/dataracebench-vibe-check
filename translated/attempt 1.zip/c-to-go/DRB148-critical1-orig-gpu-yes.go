/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/*
This example is referred from DataRaceOnAccelerator : A Micro-benchmark Suite for Evaluating
Correctness Tools Targeting Accelerators.
Though we have used critical directive to ensure that addition and subtraction are not overlapped,
due to different locks addlock@30:26 and sublock@33:26 interleave each others operation.
Data Race pairs, var@31:5:W vs. var@34:5:W
*/


package main

import (
    "fmt"
    "sync"
)



#define N 100

var var = 0

var main int(){

  for(i=0; i<N; i++){
var++

var -= 2
  }

fmt.Printf("%d\n",var)


}
