/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/* The safelen(2) clause safelen(2)@24:20 guarantees that the vector code is safe for vectors up to 2 (inclusive).
 * In the loop, m can be 2 or more for the correct execution. If the value of m is less than 2,
 * the behavior is undefined. No Data Race in b[i]@26:5 assignment.
 * */


package main

import (
    "fmt"
    "sync"
)




var main int(){

var i int, m=2, n=4
b := make([]int, 4) = {}

  for (i = m; i<n; i++)
b[i] = b[i-m] - 1.0f

fmt.Printf("Expected: -1; Real: %d\n",b[3])

}


