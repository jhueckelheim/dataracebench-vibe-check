# C-to-Go Translation Fix Guide

## Overview
This guide provides patterns for fixing common C-to-Go translation issues in the DataRaceBench files.

## Common Issues and Solutions

### 1. License Header Structure
**Problem:** License text appears outside comment blocks
**Solution:** Wrap entire license in `/* */` comments

### 2. Package Declaration
**Problem:** `package main` appears in wrong location
**Solution:** Place after license header:
```go
*/

package main

import (
    "fmt"
    "sync"
)
```

### 3. Main Function Declaration
**Problem:** C-style declarations like `var main (void)` or `int main(...)`
**Solution:** Use Go syntax:
```go
func main() {
    // code here
}
```

### 4. Variable Declarations
**Problem:** C-style like `var i int=0`
**Solution:** Proper Go spacing:
```go
var i int = 0
var length = 1000  // type inference
```

### 5. For Loop Syntax
**Problem:** C-style `for (i=0; i<len; i++)`
**Solution:** Go syntax with braces:
```go
for i = 0; i < length; i++ {
    // loop body
}
```

### 6. Array Operations
**Problem:** Missing braces or incorrect syntax
**Solution:** Proper Go array operations:
```go
a := make([]int, 1000)
for i = 0; i < length; i++ {
    a[i] = i
}
```

### 7. Printf Statements
**Problem:** `printf(...)`
**Solution:** Use fmt package:
```go
fmt.Printf("a[500]=%d\n", a[500])
```

### 8. Unused Variables
**Problem:** `var wg sync.WaitGroup` is declared but not used
**Solution:** Add suppression:
```go
var wg sync.WaitGroup
_ = wg // Suppress unused variable warning
```

### 9. Return Statements
**Problem:** `return 0` in main function
**Solution:** Remove it (Go main doesn't return values)

## Standard Template

```go
/*
[LICENSE HEADER TEXT]
*/

package main

import (
    "fmt"
    "sync"
)

func main() {
    // Variable declarations
    var i int
    var length = 1000
    
    // Array declarations
    a := make([]int, 1000)
    
    // WaitGroup (usually unused but required for compatibility)
    var wg sync.WaitGroup
    _ = wg // Suppress unused variable warning
    
    // Main logic with proper Go syntax
    for i = 0; i < length; i++ {
        a[i] = i
    }
    
    // Output
    fmt.Printf("result=%d\n", a[500])
}
```

## Files Fixed Successfully
- ✅ DRB056-jacobi2d-tile-no.go (complex tiling algorithm)
- ✅ DRB108-atomic-orig-no.go (simple atomic operations)
- ✅ DRB001-antidep1-orig-yes.go (array operations with loops)
- ✅ DRB018-plusplus-orig-yes.go (increment operations)

## Next Steps
1. Apply this pattern to remaining 204 files
2. Test compilation with `go build filename.go`
3. Test execution with `./filename`
4. Handle any special cases that don't fit the standard pattern

## Special Cases to Watch For
- Complex nested loops
- Multiple function definitions
- Pointer operations
- GPU-specific code patterns
- Advanced synchronization primitives 