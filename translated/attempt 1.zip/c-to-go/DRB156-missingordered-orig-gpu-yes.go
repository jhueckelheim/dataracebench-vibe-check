/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*This example is referred from DRACC by Adrian Schmitz et al.
Missing ordered directive causes data race pairs var[i]@28:5:W vs. var[i-1]@28:12:R
*/



package main


import (
	"fmt"
	"os"
	"strconv"
	"sync"
)


	#define N 100

	var main int
	var var int
	for i = 0; i < N; i++ {
	var[i] = 0
}

	for i = 1; i < N; i++ {
	var[i] = var[i-1]+1
}

	for i = 0; i < N; i++ {
	    if(var[i]!=i){
	fmt.Printf("Data Race Present\n")

}
}

}
