/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
Number of threads is empirical: We need enough threads so that
the reduction is really performed hierarchically in the barrier!
There is no data race.
*/


package main

import (
    "fmt"
    "sync"
)




int main(int argc, char* argv[])
{
var var = 0, i, res
var sum1 = 0
var sum2 = 0

res = omp_get_max_threads()

  {
    for (i=0; i<5; i++)
sum1+=i
    for (i=0; i<5; i++)
sum2+=i

var = sum1 + sum2
  }

  int error = (var != 20*res);
  if (error) fmt.Printf("%d %d\n",var,20*res);
return error
}
