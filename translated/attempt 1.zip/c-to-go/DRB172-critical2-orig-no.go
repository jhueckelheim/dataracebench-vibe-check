/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/* This kernel imitates the nature of a program from the NAS Parallel Benchmarks 3.0 MG suit.
 * The private(i) inline 27 and explicit barrier inline 35 will ensure synchronized behavior.
 * No Data Race Pairs.
 */



package main


import (
	"fmt"
	"os"
	"strconv"
	"sync"
)



	var main int
	var i int
	q := make([]double, 10), qq[10]

	for i = 0; i < 10; i++ {
	for i = 0; i < 10; i++ {

	  {
	for i = 0; i < 10; i++ {
	q[i] += qq[i]

	    {
	q[9] += 1.0
}
	    {
	q[9] = q[9] - 1.0
}

}

	for i = 0; i < 10; i++ {


}

