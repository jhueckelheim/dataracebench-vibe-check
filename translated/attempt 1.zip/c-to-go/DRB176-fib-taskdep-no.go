/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/* 
 * Fibonacci code without data race
 * No Data Race Pair
 * */


package main

import (
    "fmt"
    "sync"
)



var fib int(n) {
var i int, j, s
  if (n < 2)
return n
i = fib(n - 1)
j = fib(n - 2)
s = i + j
return s
}

int main(int argc, char **argv) {
var n = 10
  if (argc > 1)
n = strconv.Atoi(argv[1])
  { fmt.Printf("fib(%i) = %i\n", n, fib(n)); }

}
