/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
This kernel is modified version from “DataRaceOnAccelerator A Micro-benchmark Suite for Evaluating
Correctness Tools Targeting Accelerators” by Adrian Schmitz et al.
Due to distribute parallel for simd directive at line 31, there is a data race at line 33.
Data Race Pairs, var[i]@33:5:W vs. var[i-C]@33:12:R
.*/


package main

import (
    "fmt"
    "sync"
)


#define N 100
#define C 16

var main int(){
var var int[N]

  for(i=0; i<N; i++){
var[i]=0
  }

  for (i=C; i<N; i++){
var[i]=var[i-C]+1
  }

fmt.Printf("%d\n",var[97])


}
