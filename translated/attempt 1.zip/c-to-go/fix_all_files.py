#!/usr/bin/env python3
"""
Comprehensive script to fix C-to-Go translation issues in DataRaceBench files.
"""

import os
import re
import glob
import shutil

def fix_file(filepath):
    """Fix a single Go file with common translation issues."""
    print(f"Processing: {filepath}")
    
    # Read the file
    with open(filepath, 'r') as f:
        content = f.read()
    
    # Backup the original file
    backup_path = filepath + '.backup'
    if not os.path.exists(backup_path):
        shutil.copy2(filepath, backup_path)
    
    # Split into lines for easier processing
    lines = content.split('\n')
    new_lines = []
    
    # Track what we've seen
    found_package = False
    found_imports = False
    in_license = False
    license_lines = []
    
    i = 0
    while i < len(lines):
        line = lines[i]
        
        # Start of multi-line comment (license)
        if line.strip().startswith('/*'):
            in_license = True
            license_lines.append(line)
        
        # End of multi-line comment
        elif line.strip().endswith('*/') and in_license:
            license_lines.append(line)
            in_license = False
            
            # Add all license lines to new_lines
            new_lines.extend(license_lines)
            license_lines = []
        
        # Inside license block
        elif in_license:
            license_lines.append(line)
        
        # Package declaration - make sure it comes after license
        elif line.strip() == 'package main' and not found_package:
            if not in_license:
                new_lines.append('')
                new_lines.append('package main')
                found_package = True
            
        # Import block - collect and fix
        elif line.strip().startswith('import (') and not found_imports:
            if not in_license:
                new_lines.append('')
                new_lines.append('import (')
                new_lines.append('\t"fmt"')
                new_lines.append('\t"os"')
                new_lines.append('\t"strconv"')
                new_lines.append('\t"sync"')
                new_lines.append(')')
                found_imports = True
                
                # Skip until we find the closing ')'
                i += 1
                while i < len(lines) and not lines[i].strip().endswith(')'):
                    i += 1
        
        # Skip standalone package/import if we haven't processed license yet
        elif (line.strip() == 'package main' or line.strip().startswith('import (')) and in_license:
            # Skip this line as it's in the wrong place
            pass
        
        # Handle main function declaration
        elif re.match(r'int main\(int argc, char\*\s*argv\[\]\)', line):
            new_lines.append('')
            new_lines.append('func main() {')
            new_lines.append('\tvar length = 1000')
            new_lines.append('')
            new_lines.append('\tif len(os.Args) > 1 {')
            new_lines.append('\t\tif val, err := strconv.Atoi(os.Args[1]); err == nil {')
            new_lines.append('\t\t\tlength = val')
            new_lines.append('\t\t}')
            new_lines.append('\t}')
            new_lines.append('')
        
        # Handle variable declarations
        elif re.match(r'var\s+(\w+)\s+int', line):
            var_name = re.match(r'var\s+(\w+)\s+int', line).group(1)
            new_lines.append(f'\tvar {var_name} int')
        
        # Handle variable declarations with initialization
        elif re.match(r'var\s+(\w+)\s*=\s*(\d+)', line):
            var_name = re.match(r'var\s+(\w+)\s*=\s*(\d+)', line).group(1)
            value = re.match(r'var\s+(\w+)\s*=\s*(\d+)', line).group(2)
            new_lines.append(f'\tvar {var_name} = {value}')
        
        # Handle array declarations
        elif re.match(r'var\s+(\w+)\s+(int|float64)\[(\w+)\]', line):
            match = re.match(r'var\s+(\w+)\s+(int|float64)\[(\w+)\]', line)
            var_name = match.group(1)
            var_type = match.group(2)
            size = match.group(3)
            new_lines.append(f'\t{var_name} := make([]{var_type}, {size})')
        
        # Handle for loops
        elif re.match(r'\s*for\s*\(\s*(\w+)\s*=\s*(\d+)\s*;\s*(\w+)\s*<\s*(\w+)\s*;\s*(\w+)\+\+\s*\)', line):
            match = re.match(r'\s*for\s*\(\s*(\w+)\s*=\s*(\d+)\s*;\s*(\w+)\s*<\s*(\w+)\s*;\s*(\w+)\+\+\s*\)', line)
            var_name = match.group(1)
            start = match.group(2)
            condition_var = match.group(3)
            end_var = match.group(4)
            increment_var = match.group(5)
            
            indent = '\t' if not line.startswith('\t') else '\t\t'
            new_lines.append(f'{indent}for {var_name} = {start}; {condition_var} < {end_var}; {increment_var}++ {{')
        
        # Handle array assignments
        elif re.match(r'\s*(\w+)\[(\w+)\]\s*=\s*(.+)', line):
            match = re.match(r'\s*(\w+)\[(\w+)\]\s*=\s*(.+)', line)
            array_name = match.group(1)
            index = match.group(2)
            value = match.group(3)
            
            indent = '\t' if not line.startswith('\t') else '\t\t'
            new_lines.append(f'{indent}{array_name}[{index}] = {value}')
        
        # Handle sync.WaitGroup
        elif 'var wg sync.WaitGroup' in line:
            new_lines.append('\tvar wg sync.WaitGroup')
            new_lines.append('\t_ = wg  // Suppress unused variable warning')
        
        # Handle closing braces
        elif line.strip() == '}':
            new_lines.append('}')
        
        # Handle other lines that don't match special patterns
        else:
            # Skip empty lines that are part of misplaced code
            if line.strip() and not in_license:
                # Fix common issues
                line = line.replace('printf', 'fmt.Printf')
                line = line.replace('strconv.Atoi(argv[1])', 'strconv.Atoi(os.Args[1])')
                
                # Add proper indentation if it's inside main
                if found_package and not line.startswith('\t') and line.strip():
                    line = '\t' + line
                
                new_lines.append(line)
            elif not line.strip():
                new_lines.append(line)
        
        i += 1
    
    # Ensure we have package and imports if missing
    if not found_package:
        # Find the end of license block
        license_end = -1
        for i, line in enumerate(new_lines):
            if line.strip().endswith('*/'):
                license_end = i
                break
        
        if license_end >= 0:
            new_lines.insert(license_end + 1, '')
            new_lines.insert(license_end + 2, 'package main')
            new_lines.insert(license_end + 3, '')
    
    if not found_imports:
        # Find package main
        package_line = -1
        for i, line in enumerate(new_lines):
            if line.strip() == 'package main':
                package_line = i
                break
        
        if package_line >= 0:
            new_lines.insert(package_line + 1, '')
            new_lines.insert(package_line + 2, 'import (')
            new_lines.insert(package_line + 3, '\t"fmt"')
            new_lines.insert(package_line + 4, '\t"os"')
            new_lines.insert(package_line + 5, '\t"strconv"')
            new_lines.insert(package_line + 6, '\t"sync"')
            new_lines.insert(package_line + 7, ')')
    
    # Write the fixed content
    new_content = '\n'.join(new_lines)
    
    with open(filepath, 'w') as f:
        f.write(new_content)
    
    print(f"Fixed: {filepath}")
    return True

def main():
    """Main function to process all Go files."""
    # Find all Go files
    go_files = glob.glob('DRB*.go')
    
    # Skip already fixed files
    fixed_files = {
        'DRB001-antidep1-orig-yes.go',
        'DRB018-plusplus-orig-yes.go', 
        'DRB056-jacobi2d-tile-no.go',
        'DRB108-atomic-orig-no.go'
    }
    
    files_to_fix = [f for f in go_files if f not in fixed_files]
    
    print(f"Found {len(files_to_fix)} files to fix")
    
    success_count = 0
    for filepath in files_to_fix[:5]:  # Start with first 5 files
        try:
            if fix_file(filepath):
                success_count += 1
        except Exception as e:
            print(f"Error processing {filepath}: {e}")
    
    print(f"\nProcessed {success_count} files successfully")

if __name__ == "__main__":
    main() 