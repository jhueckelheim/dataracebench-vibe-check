/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/*
The increment at line number 26 is critical for the variable
var@26:5. Therefore, there is a possible Data Race pair var@26:5:W vs. var@26:5:W
*/


package main

import (
    "fmt"
    "sync"
)


#define N 100

var var = 0

var main int(){
  for(int i=0; i<N*2; i++){
var++
  }

fmt.Printf("%d\n ",var)


}
