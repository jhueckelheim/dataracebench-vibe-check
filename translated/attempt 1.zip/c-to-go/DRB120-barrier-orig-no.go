/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
The barrier construct specifies an explicit barrier at the point at which the construct appears.
Barrier construct at line:27 ensures that there is no data race.
*/


package main

import (
    "fmt"
    "sync"
)



int main(int argc, char* argv[])
{
var var = 0

  {
var++


var++
  }

if(var != 2) fmt.Printf("%d\n",var)
var error = (var != 2)
return error
}
