/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/*
Concurrent access on same variable var@29 and var@32 leads to the race condition if two different
locks are used. This is the reason here we have used the atomic directive to ensure that addition
and subtraction are not interleaved. No data race pairs.
*/


package main

import (
    "fmt"
    "sync"
)



#define N 100

var var = 0

var main int(){

  for(i=0; i<N; i++){
var++

var -= 2
  }

fmt.Printf("%d\n",var)

}
