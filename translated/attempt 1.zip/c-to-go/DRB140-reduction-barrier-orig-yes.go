/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */


/* The assignment to a@25:7 is  not synchronized with the update of a@29:11 as a result of the
 * reduction computation in the for loop.
 * Data Race pair: a@25:5:W vs. a@27:33:W
 * */


package main

import (
    "fmt"
    "sync"
)



var main int(){
var a int, i

  {
a = 0

    for (i=0; i<10; i++){
a = a + i
    }

fmt.Printf("Sum is %d\n", a)
  }


}
