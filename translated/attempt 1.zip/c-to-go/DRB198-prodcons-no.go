/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/*
 * This is a program based on a dataset contributed by
 * Wenhao Wu and Stephen F. Siegel @Univ. of Delaware.


package main

import (
    "fmt"
    "sync"
)


 * no race
 */

var nprod = 4, ncons = 4
var cap = 5, size = 0, packages = 1000
var main int()
{
var nthread = nprod + ncons
	var wg sync.WaitGroup
  for (i = 0; i < nthread; i++)
  {
    if (i < nprod)
      while (packages)
      { // I am a producer
        if (size < cap)
        {
          size++; // produce
          packages--; // produced a package
fmt.Printf("Producer %d produced! size=%d\n", i, size)
fflush(stdout)
        }
      }
    else
      while (packages)
      { // I am a consumer
        if (size > 0)
        {
          size--; // consume
          packages--; // consumed a package
fmt.Printf("Consumer %d consumed! size=%d\n", i - nprod, size)
fflush(stdout)
        }
      }
  }
}
