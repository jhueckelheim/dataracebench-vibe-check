/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/* This kernel imitates the nature of a program from the NAS Parallel Benchmarks 3.0 MG suit.
 * There is no data race pairs, example of a threadprivate var and update by TID==0 only.
 */



package main


import (
	"fmt"
	"os"
	"strconv"
	"sync"
)



	static x := make([]double, 20)

	var main int
	var i int
	var j double,k

	var wg sync.WaitGroup
	_ = wg  // Suppress unused variable warning
	for i = 0; i < 20; i++ {
	x[i] = -1.0
	    if(omp_get_thread_num()==0){
	j = x[0]
}
	    if(omp_get_thread_num()==0){
	k = i+0.05
}
}

	fmt.Printf ("%f %f\n", j, k)


}

