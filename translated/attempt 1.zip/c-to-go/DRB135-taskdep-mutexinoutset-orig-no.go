/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */


/* Addition of mutexinoutset dependence type on c, will ensure that line d@37:7 assignment will depend
 * on task at Line 32 and line 34. They might execute in any order but not at the same time.
 * There is no data race.
 * */


package main

import (
    "fmt"
    "sync"
)




var main int(){
var a int, b, c, d

  {
c = 1
a = 2
b = 3
c += a
c += b
d = c
  }

fmt.Printf("%d\n",d)

}
