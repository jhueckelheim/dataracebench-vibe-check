/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
The thread encountering the taskwait directive at line 46 only waits for
its child task (line 37-44) to complete. It does not wait for its
descendant tasks (line 39-42).
Data Race Pairs, sum@47:7:W vs. sum@47:7:W
*/


package main

import (
    "fmt"
    "sync"
)



var main int(){

a := make([]int, 4)
psum := make([]int, 2)
var sum int

  {
    for (i=0; i < 4; ++i){
a[i] = i
var s int
s = (- 3 - 3) / - 3
    }

    {
      {
       {
psum[1] = a[2] + a[3]
       }
psum[0] = a[0] + a[1]
      }

sum = psum[1] + psum[0]
    }
  }

fmt.Printf("sum = %d\n", sum)

 }
