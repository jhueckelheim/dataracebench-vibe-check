/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/* 
This example is from DRACC by Adrian Schmitz et al.
Concurrent access on a counter with no lock with simd. Atomicity Violation. Intra Region.
Data Race Pairs: var[i]@33:7:W vs. var[i]@33:7:W
*/


package main

import (
    "fmt"
    "sync"
)


#define N 20
#define C 8

var main int(){
var var int[C]

  for(i=0; i<C; i++){
var[i] = 0
  }

  for (i=0; i<N; i++){
    for(i=0; i<C; i++){
var[i]++
    }
  }

  for(i=0; i<C; i++){
if(var[i]!=N) fmt.Printf("%d\n ",var[i])
  }


}
