/**
 * jacobi-2d-imper.c: This file is part of the PolyBench/C 3.2 test suite.
 * Jacobi with array copying, no reduction. with tiling and nested SIMD.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Web address: http://polybench.sourceforge.net
 * License: /LICENSE.OSU.txt
 */
/* Include polybench common header. */
/* Include benchmark-specific header. */
/* Default data type is double, default size is 20x1000. */
/* Array initialization. */

package main

import (
	"fmt"
	"os"
	"strconv"
	"sync"
	"unsafe"
)

func init_array(n int, A *[500][500]float64, B *[500][500]float64) {
	//int i;
	//int j;
	{
		var c1 int
		var c2 int
		var c4 int
		var c3 int
		if n >= 1 {
			var wg sync.WaitGroup
			_ = wg
			for c1 = 0; c1 <= func() int {
				if (n-1)*16 < 0 {
					if 16 < 0 {
						return -((-(n - 1) + 16 + 1) / 16)
					} else {
						return -((-(n - 1) + 16 - 1) / 16)
					}
				} else {
					return (n - 1) / 16
				}
			}(); c1++ {
				for c2 = 0; c2 <= func() int {
					if (n-1)*16 < 0 {
						if 16 < 0 {
							return -((-(n - 1) + 16 + 1) / 16)
						} else {
							return -((-(n - 1) + 16 - 1) / 16)
						}
					} else {
						return (n - 1) / 16
					}
				}(); c2++ {
					for c3 = 16 * c2; c3 <= func() int {
						if 16*c2+15 < n-1 {
							return 16*c2 + 15
						} else {
							return n - 1
						}
					}(); c3++ {
						for c4 = 16 * c1; c4 <= func() int {
							if 16*c1+15 < n-1 {
								return 16*c1 + 15
							} else {
								return n - 1
							}
						}(); c4++ {
							A[c4][c3] = (float64(c4)*(float64(c3)+2) + 2) / float64(n)
							B[c4][c3] = (float64(c4)*(float64(c3)+3) + 3) / float64(n)
						}
					}
				}
			}
		}
	}
}

/* DCE code. Must scan the entire live-out data.
   Can be used also to check the correctness of the output. */

func print_array(n int, A *[500][500]float64) {
	var i int
	var j int
	for i = 0; i < n; i++ {
		for j = 0; j < n; j++ {
			fmt.Fprintf(os.Stderr, "%0.2f ", A[i][j])
			if (i*n+j)%20 == 0 {
				fmt.Fprintf(os.Stderr, "\n")
			}
		}
	}
	fmt.Fprintf(os.Stderr, "\n")
}

/* Main computational kernel. The whole function will be timed,
   including the call and return. */

func kernel_jacobi_2d_imper(tsteps int, n int, A *[500][500]float64, B *[500][500]float64) {
	//int t;
	//int i;
	//int j;

	//#pragma scop
	{
		var c0 int
		var c1 int
		var c3 int
		var c2 int
		var c4 int
		var c5 int
		if n >= 3 && tsteps >= 1 {
			for c0 = 0; c0 <= func() int {
				if (n+3*tsteps-4)*16 < 0 {
					if 16 < 0 {
						return -((-(n + 3*tsteps - 4) + 16 + 1) / 16)
					} else {
						return -((-(n + 3*tsteps - 4) + 16 - 1) / 16)
					}
				} else {
					return (n + 3*tsteps - 4) / 16
				}
			}(); c0++ {
				var wg sync.WaitGroup
				_ = wg
				for c1 = func() int {
					val1 := func() int {
						if 2*c0*3 < 0 {
							return -(-(2 * c0) / 3)
						} else {
							if 3 < 0 {
								return (-(2 * c0) + -3 - 1) / -3
							} else {
								return (2*c0 + 3 - 1) / 3
							}
						}
					}()
					val2 := func() int {
						if (16*c0+-1*tsteps+1)*16 < 0 {
							return -(-(16*c0 + -1*tsteps + 1) / 16)
						} else {
							if 16 < 0 {
								return (-(16*c0 + -1*tsteps + 1) + -16 - 1) / -16
							} else {
								return (16*c0 + -1*tsteps + 1 + 16 - 1) / 16
							}
						}
					}()
					if val1 > val2 {
						return val1
					} else {
						return val2
					}
				}(); c1 <= func() int {
					val1 := func() int {
						if (n+2*tsteps-3)*16 < 0 {
							if 16 < 0 {
								return -((-(n + 2*tsteps - 3) + 16 + 1) / 16)
							} else {
								return -((-(n + 2*tsteps - 3) + 16 - 1) / 16)
							}
						} else {
							return (n + 2*tsteps - 3) / 16
						}
					}()
					val2 := func() int {
						if (32*c0+n+29)*48 < 0 {
							if 48 < 0 {
								return -((-(32*c0 + n + 29) + 48 + 1) / 48)
							} else {
								return -((-(32*c0 + n + 29) + 48 - 1) / 48)
							}
						} else {
							return (32*c0 + n + 29) / 48
						}
					}()
					if val1 < val2 {
						val1 = val1
					} else {
						val1 = val2
					}
					if val1 < c0 {
						return val1
					} else {
						return c0
					}
				}(); c1++ {
					for c2 = func() int {
						val1 := func() int {
							if (16*c1+-1*n+-12)*16 < 0 {
								return -(-(16*c1 + -1*n + -12) / 16)
							} else {
								if 16 < 0 {
									return (-(16*c1 + -1*n + -12) + -16 - 1) / -16
								} else {
									return (16*c1 + -1*n + -12 + 16 - 1) / 16
								}
							}
						}()
						val2 := 2*c0 + -2*c1
						if val1 > val2 {
							return val1
						} else {
							return val2
						}
					}(); c2 <= func() int {
						val1 := func() int {
							if (16*c1+n+12)*16 < 0 {
								if 16 < 0 {
									return -((-(16*c1 + n + 12) + 16 + 1) / 16)
								} else {
									return -((-(16*c1 + n + 12) + 16 - 1) / 16)
								}
							} else {
								return (16*c1 + n + 12) / 16
							}
						}()
						val2 := func() int {
							if (n+2*tsteps-3)*16 < 0 {
								if 16 < 0 {
									return -((-(n + 2*tsteps - 3) + 16 + 1) / 16)
								} else {
									return -((-(n + 2*tsteps - 3) + 16 - 1) / 16)
								}
							} else {
								return (n + 2*tsteps - 3) / 16
							}
						}()
						if val1 < val2 {
							val1 = val1
						} else {
							val1 = val2
						}
						val3 := func() int {
							if (32*c0+-32*c1+n+29)*16 < 0 {
								if 16 < 0 {
									return -((-(32*c0 + -32*c1 + n + 29) + 16 + 1) / 16)
								} else {
									return -((-(32*c0 + -32*c1 + n + 29) + 16 - 1) / 16)
								}
							} else {
								return (32*c0 + -32*c1 + n + 29) / 16
							}
						}()
						if val1 < val3 {
							return val1
						} else {
							return val3
						}
					}(); c2++ {
						if c0 <= func() int {
							if (32*c1+16*c2+-1*n+1)*32 < 0 {
								if 32 < 0 {
									return -((-(32*c1 + 16*c2 + -1*n + 1) + 32 + 1) / 32)
								} else {
									return -((-(32*c1 + 16*c2 + -1*n + 1) + 32 - 1) / 32)
								}
							} else {
								return (32*c1 + 16*c2 + -1*n + 1) / 32
							}
						}() && c1 <= c2+-1 {
							if (n+1)%2 == 0 {
								for c4 = func() int {
									if 16*c1 > 16*c2+-1*n+3 {
										return 16 * c1
									} else {
										return 16*c2 + -1*n + 3
									}
								}(); c4 <= 16*c1+15; c4++ {
									A[-16*c2+c4+n+-2][n+-2] = B[-16*c2+c4+n+-2][n+-2]
								}
							}
						}
						if c0 <= func() int {
							if (48*c1+-1*n+1)*32 < 0 {
								if 32 < 0 {
									return -((-(48*c1 + -1*n + 1) + 32 + 1) / 32)
								} else {
									return -((-(48*c1 + -1*n + 1) + 32 - 1) / 32)
								}
							} else {
								return (48*c1 + -1*n + 1) / 32
							}
						}() && c1 >= c2 {
							if (n+1)%2 == 0 {
								for c5 = func() int {
									if 16*c2 > 16*c1+-1*n+3 {
										return 16 * c2
									} else {
										return 16*c1 + -1*n + 3
									}
								}(); c5 <= func() int {
									if 16*c1 < 16*c2+15 {
										return 16 * c1
									} else {
										return 16*c2 + 15
									}
								}(); c5++ {
									A[n+-2][-16*c1+c5+n+-2] = B[n+-2][-16*c1+c5+n+-2]
								}
							}
						}
						// Simplified the complex loop condition for readability
						for c3 = func() int {
							val1 := func() int {
								if (16*c1+-1*n+2)*2 < 0 {
									return -(-(16*c1 + -1*n + 2) / 2)
								} else {
									if 2 < 0 {
										return (-(16*c1 + -1*n + 2) + -2 - 1) / -2
									} else {
										return (16*c1 + -1*n + 2 + 2 - 1) / 2
									}
								}
							}()
							val2 := func() int {
								if (16*c2+-1*n+2)*2 < 0 {
									return -(-(16*c2 + -1*n + 2) / 2)
								} else {
									if 2 < 0 {
										return (-(16*c2 + -1*n + 2) + -2 - 1) / -2
									} else {
										return (16*c2 + -1*n + 2 + 2 - 1) / 2
									}
								}
							}()
							if val1 > val2 {
								val1 = val1
							} else {
								val1 = val2
							}
							val3 := 16*c0 + -16*c1
							if val1 > val3 {
								return val1
							} else {
								return val3
							}
						}(); c3 <= func() int {
							val1 := func() int {
								if 8*c1+6 < 8*c2+6 {
									return 8*c1 + 6
								} else {
									return 8*c2 + 6
								}
							}()
							if val1 < tsteps-1 {
								val1 = val1
							} else {
								val1 = tsteps - 1
							}
							val2 := 16*c0 + -16*c1 + 15
							if val1 < val2 {
								return val1
							} else {
								return val2
							}
						}(); c3++ {
							if c1 <= func() int {
								if c3*8 < 0 {
									if 8 < 0 {
										return -((-c3 + 8 + 1) / 8)
									} else {
										return -((-c3 + 8 - 1) / 8)
									}
								} else {
									return c3 / 8
								}
							}() {
								for c5 = func() int {
									if 16*c2 > 2*c3+1 {
										return 16 * c2
									} else {
										return 2*c3 + 1
									}
								}(); c5 <= func() int {
									if 16*c2+15 < 2*c3+n+-2 {
										return 16*c2 + 15
									} else {
										return 2*c3 + n + -2
									}
								}(); c5++ {
									B[1][-2*c3+c5] = 0.2 * (A[1][-2*c3+c5] + A[1][-2*c3+c5-1] + A[1][1+(-2*c3+c5)] + A[1+1][-2*c3+c5] + A[1-1][-2*c3+c5])
								}
							}
							for c4 = func() int {
								if 16*c1 > 2*c3+2 {
									return 16 * c1
								} else {
									return 2*c3 + 2
								}
							}(); c4 <= func() int {
								if 16*c1+15 < 2*c3+n+-2 {
									return 16*c1 + 15
								} else {
									return 2*c3 + n + -2
								}
							}(); c4++ {
								if c2 <= func() int {
									if c3*8 < 0 {
										if 8 < 0 {
											return -((-c3 + 8 + 1) / 8)
										} else {
											return -((-c3 + 8 - 1) / 8)
										}
									} else {
										return c3 / 8
									}
								}() {
									B[-2*c3+c4][1] = 0.2 * (A[-2*c3+c4][1] + A[-2*c3+c4][1-1] + A[-2*c3+c4][1+1] + A[1+(-2*c3+c4)][1] + A[-2*c3+c4-1][1])
								}
								for c5 = func() int {
									if 16*c2 > 2*c3+2 {
										return 16 * c2
									} else {
										return 2*c3 + 2
									}
								}(); c5 <= func() int {
									if 16*c2+15 < 2*c3+n+-2 {
										return 16*c2 + 15
									} else {
										return 2*c3 + n + -2
									}
								}(); c5++ {
									B[-2*c3+c4][-2*c3+c5] = 0.2 * (A[-2*c3+c4][-2*c3+c5] + A[-2*c3+c4][-2*c3+c5-1] + A[-2*c3+c4][1+(-2*c3+c5)] + A[1+(-2*c3+c4)][-2*c3+c5] + A[-2*c3+c4-1][-2*c3+c5])
									A[-2*c3+c4+-1][-2*c3+c5+-1] = B[-2*c3+c4+-1][-2*c3+c5+-1]
								}
								if c2 >= func() int {
									if (2*c3+n+-16)*16 < 0 {
										return -(-(2*c3 + n + -16) / 16)
									} else {
										if 16 < 0 {
											return (-(2*c3 + n + -16) + -16 - 1) / -16
										} else {
											return (2*c3 + n + -16 + 16 - 1) / 16
										}
									}
								}() {
									A[-2*c3+c4+-1][n+-2] = B[-2*c3+c4+-1][n+-2]
								}
							}
							if c1 >= func() int {
								if (2*c3+n+-16)*16 < 0 {
									return -(-(2*c3 + n + -16) / 16)
								} else {
									if 16 < 0 {
										return (-(2*c3 + n + -16) + -16 - 1) / -16
									} else {
										return (2*c3 + n + -16 + 16 - 1) / 16
									}
								}
							}() {
								for c5 = func() int {
									if 16*c2 > 2*c3+2 {
										return 16 * c2
									} else {
										return 2*c3 + 2
									}
								}(); c5 <= func() int {
									if 16*c2+15 < 2*c3+n+-1 {
										return 16*c2 + 15
									} else {
										return 2*c3 + n + -1
									}
								}(); c5++ {
									A[n+-2][-2*c3+c5+-1] = B[n+-2][-2*c3+c5+-1]
								}
							}
						}
						if c0 >= func() int {
							if (2*c1+c2+-1)*2 < 0 {
								return -(-(2*c1 + c2 + -1) / 2)
							} else {
								if 2 < 0 {
									return (-(2*c1 + c2 + -1) + -2 - 1) / -2
								} else {
									return (2*c1 + c2 + -1 + 2 - 1) / 2
								}
							}
						}() && c1 >= c2+1 && c2 <= func() int {
							if (tsteps+-8)*8 < 0 {
								if 8 < 0 {
									return -((-(tsteps + -8) + 8 + 1) / 8)
								} else {
									return -((-(tsteps + -8) + 8 - 1) / 8)
								}
							} else {
								return (tsteps + -8) / 8
							}
						}() {
							for c4 = 16 * c1; c4 <= func() int {
								if 16*c1+15 < 16*c2+n+12 {
									return 16*c1 + 15
								} else {
									return 16*c2 + n + 12
								}
							}(); c4++ {
								B[-16*c2+c4+-14][1] = 0.2 * (A[-16*c2+c4+-14][1] + A[-16*c2+c4+-14][1-1] + A[-16*c2+c4+-14][1+1] + A[1+(-16*c2+c4+-14)][1] + A[-16*c2+c4+-14-1][1])
							}
						}
						if c0 >= func() int {
							if (3*c1+-1)*2 < 0 {
								return -(-(3*c1 + -1) / 2)
							} else {
								if 2 < 0 {
									return (-(3*c1 + -1) + -2 - 1) / -2
								} else {
									return (3*c1 + -1 + 2 - 1) / 2
								}
							}
						}() && c1 <= func() int {
							val1 := func() int {
								if (tsteps+-8)*8 < 0 {
									if 8 < 0 {
										return -((-(tsteps + -8) + 8 + 1) / 8)
									} else {
										return -((-(tsteps + -8) + 8 - 1) / 8)
									}
								} else {
									return (tsteps + -8) / 8
								}
							}()
							if val1 < c2 {
								return val1
							} else {
								return c2
							}
						}() {
							for c5 = func() int {
								if 16*c2 > 16*c1+15 {
									return 16 * c2
								} else {
									return 16*c1 + 15
								}
							}(); c5 <= func() int {
								if 16*c2+15 < 16*c1+n+12 {
									return 16*c2 + 15
								} else {
									return 16*c1 + n + 12
								}
							}(); c5++ {
								B[1][-16*c1+c5+-14] = 0.2 * (A[1][-16*c1+c5+-14] + A[1][-16*c1+c5+-14-1] + A[1][1+(-16*c1+c5+-14)] + A[1+1][-16*c1+c5+-14] + A[1-1][-16*c1+c5+-14])
							}
						}
					}
				}
			}
		}
	}

	//#pragma endscop
}

func main() {
	/* Retrieve problem size. */
	var n = 500
	var tsteps = 10

	if len(os.Args) > 1 {
		if val, err := strconv.Atoi(os.Args[1]); err == nil {
			n = val
		}
	}
	if len(os.Args) > 2 {
		if val, err := strconv.Atoi(os.Args[2]); err == nil {
			tsteps = val
		}
	}

	/* Variable declaration/allocation. */
	var A [500][500]float64
	var B [500][500]float64

	/* Initialize array(s). */
	init_array(n, &A, &B)

	/* Start timer. */
	// polybench_timer_start()

	/* Run kernel. */
	kernel_jacobi_2d_imper(tsteps, n, &A, &B)

	/* Stop and print timer. */
	// polybench_timer_stop()
	// polybench_timer_print()

	/* Prevent dead-code elimination. All live-out data must be printed
	   by the function call in argument. */
	if len(os.Args) > 42 && os.Args[0] == "" {
		print_array(n, &A)
	}

	/* Memory is automatically managed in Go */
}

// Placeholder for polybench memory allocation
func polybench_alloc_data(elements int, typeSize int) unsafe.Pointer {
	// This would normally allocate memory, but in Go we use arrays directly
	return nil
}
