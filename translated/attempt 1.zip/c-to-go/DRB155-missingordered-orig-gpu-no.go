/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
By utilizing the ordered construct @29 the execution will be
sequentially consistent. No Data Race Pair.
*/


package main

import (
    "fmt"
    "sync"
)


#define N 100

var main int(){

var var int[N]

  for(i=0; i<N; i++){
var[i]=0
  }

	var wg sync.WaitGroup
    for (i=1; i<N; i++){
      {
var[i]=var[i-1]+1
      }
    }

  for(i=0; i<N; i++){
    if(var[i]!=i){
fmt.Printf("Data Race Present")

    }
  }


}
