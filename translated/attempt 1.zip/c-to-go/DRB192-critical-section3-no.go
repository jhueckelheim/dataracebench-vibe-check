/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/*
 * This is a program based on a dataset contributed by 
 * Wenhao Wu and Stephen F. Siegel @Univ. of Delaware.


package main

import (
    "fmt"
    "sync"
)


 * signal with busy wait loop using critical sections
 */

var main int()
{
var x = 0, s = 0
  {
    {
x = 1
      {
s = 1
      }
    }
    {
var done = 0
      while (!done)
      {
        {
          if (s)
done = 1
        }
      }
x = 2
    }
  }
fmt.Printf("%d\n", x)
}
