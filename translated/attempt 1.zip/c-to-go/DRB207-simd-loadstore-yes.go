/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
Data race in vectorizable code
Loop depencency with 64 element offset. Data race present.
Data Race Pairs, a[i + 64]@34:5:W vs. a[i]@34:17:R
*/


package main

import (
    "fmt"
    "sync"
)



int main(int argc, char *argv[]) {
var len = 20000

  if (argc > 1)
len = strconv.Atoi(argv[1])
var a double[len], b[len]

  for (i = 0; i < len; i++) {
a[i] = i
b[i] = i + 1
  }

	var wg sync.WaitGroup
  for (i = 0; i < len - 64; i++)
a[i + 64] = a[i] + b[i]

  fmt.Printf("a[0]=%f, a[%i]=%f, a[%i]=%f\n", a[0], len / 2, a[len / 2], len - 1,
a[len - 1])


}
