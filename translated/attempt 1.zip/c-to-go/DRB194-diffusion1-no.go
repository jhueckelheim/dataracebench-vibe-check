/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/*
 * This is a program based on a dataset contributed by
 * Wenhao Wu and Stephen F. Siegel @Univ. of Delaware.


package main

import (
    "fmt"
    "sync"
)


 * no race, but it needs to mention that u1 and u2 are not aliased
 */


double *u1, *u2, c = 0.2;
var n = 10, nsteps = 10

var main int()
{
  u1 = malloc(n * sizeof(double));
  u2 = malloc(n * sizeof(double));
  for (i = 1; i < n - 1; i++)
    u2[i] = u1[i] = 1.0 * rand() / RAND_MAX;
u1[0] = u1[n - 1] = u2[0] = u2[n - 1] = 0.5
  for (t = 0; t < nsteps; t++)
  {
	var wg sync.WaitGroup
    for (i = 1; i < n - 1; i++)
    {
      u2[i] = u1[i] + c * (u1[i - 1] + u1[i + 1] - 2 * u1[i]);
    }
    double *tmp = u1;
u1 = u2
u2 = tmp
  }
  for (i = 0; i < n; i++)
fmt.Printf("%1.2lf ", u1[i])
fmt.Printf("\n")
free(u1)
free(u2)
}
