/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/*
 * This is a program based on a dataset contributed by
 * Wenhao Wu and Stephen F. Siegel @Univ. of Delaware.


package main

import (
    "fmt"
    "sync"
)


 * Race due to different critical section names
 * Data race pair: x@27:7:W vs. x@44:7:W
 * Data race pair: s@30:9:W vs. s@40:15:R
 */

var main int()
{
var x = 0, s = 0
  {
    {
x = 1
      {
s = 1
      }
    }
    {
var done = 0
      while (!done)
      {
        {
          if (s)
done = 1
        }
      }
x = 2
    }
  }
fmt.Printf("%d\n", x)
}
