/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
Vector addition followed by multiplication involving the same var should have a barrier in between.
Here we have an implicit barrier after parallel for regions. No data race pair.
*/


package main

import (
    "fmt"
    "sync"
)


#define N 100
#define C 8


var a int
var b int[C]
var c int[C]
var temp int[C]

var main int(){
  for(i=0; i<C; i++){
b[i]=0
c[i]=2
temp[i]=0
  }
a=2

  {
    for(i=0; i<N ;i++){
      for(i=0; i<C; i++){
temp[i] = b[i] + c[i]
      }

      for(i=C-1; i>=0; i--){
        b[i] = temp[i] * a;
      }
    }
  }

var val = 0

  for(i=0; i<N; i++){
val = val + 2
    val = val * 2;
  }

  for(i=0; i<C; i++){
    if(b[i]!=val){
fmt.Printf("expected %d real %d \n",val, b[i])

    }
  }


}
