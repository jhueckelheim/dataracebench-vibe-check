/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

 /*
 * The scheduling constraints prohibit a thread in the team from executing
 * a new task that modifies tp while another such task region tied to
 * the same thread is suspended. Therefore, the value written will
 * persist across the task scheduling point.
 * No Data Race at var@35:7
 */


package main

import (
    "fmt"
    "sync"
)




var tp int
var var int

var main int(){
  {
    {
tp = 1
      {
      }
var = tp
    }
  }

}
