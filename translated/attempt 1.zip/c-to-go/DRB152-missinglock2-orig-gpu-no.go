/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
Concurrent access of var@28:5 in an intra region. Lock ensures that there is no data race.
*/


package main

import (
    "fmt"
    "sync"
)


#define N 100

var main int(){
omp_lock_t lck
var var int=0
omp_init_lock(&lck)

  for (i=0; i<N; i++){
omp_set_lock(&lck)
var++
omp_unset_lock(&lck)
  }

omp_destroy_lock(&lck)
fmt.Printf("%d\n",var)

}
