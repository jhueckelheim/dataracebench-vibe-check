/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
A single thread will spawn all the tasks. Add if(0) to avoid the data race, undeferring the tasks.


package main

import (
    "fmt"
    "sync"
)


Data Race pairs var@30:9:W vs. var@30:9:W
*/


int main(int argc, char* argv[])
{
var var = 0
var i int

  {
    for (i = 0; i < 10; i++) {
      {
var++
      }
    }
  }

if (var!=10) fmt.Printf("%d\n",var)

}
