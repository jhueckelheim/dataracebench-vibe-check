/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/* The explicit flush directive that provides at line:29 provides release semantics is needed
 * here to complete the synchronization. No data race.
 * */


package main

import (
    "fmt"
    "sync"
)




var main int(){

var x = 0, y

  {
var thrd = omp_get_thread_num()
  if (thrd == 0) {
    { x = 10; }


y = 1
  } else {
var tmp = 0
      while (tmp == 0) {
tmp = y
      }
    { if (x!=10) fmt.Printf("x = %d\n", x); }
  }
  }

}
