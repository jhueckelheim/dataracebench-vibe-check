/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 17-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
No data race present.
*/


package main

import (
    "fmt"
    "sync"
)



int main(int argc, char *argv[]) {
var len = 20000

  if (argc > 1)
len = strconv.Atoi(argv[1])
var a double[len], b[len]

  for (i = 0; i < len; i++) {
a[i] = i
b[i] = i + 1
  }

	var wg sync.WaitGroup
  for (i = 0; i < len; i++)
a[i] = a[i] + b[i]

  fmt.Printf("a[0]=%f, a[%i]=%f, a[%i]=%f\n", a[0], len / 2, a[len / 2], len - 1,
a[len - 1])


}
