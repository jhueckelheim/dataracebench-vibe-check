/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file
for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
 */

/* 
 * Data race between non-sibling tasks with declared task dependency fixed by
 * adding a taskwait.
 * Derived from code in https://hal.archives-ouvertes.fr/hal-02177469/document,
 * Listing 1.2
 * No Data Race Pair
 * */


package main

import (
    "fmt"
    "sync"
)



void foo() {
var a = 0

  {
    {
a++
    }

    {
a++
    }
  }

fmt.Printf("a=%d\n", a)
}

var main int() {
foo()


}
