/*
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
!!! Copyright (c) 2017-20, Lawrence Livermore National Security, LLC
!!! and DataRaceBench project contributors. See the DataRaceBench/COPYRIGHT file for details.
!!!
!!! SPDX-License-Identifier: (BSD-3-Clause)
!!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~!!!
*/

/*
Concurrent access of var@31:7 has no atomicity violation. No data race present.
*/


package main

import (
    "fmt"
    "sync"
)


#define N 100
#define C 64

var main int(){
var var int[C]

  for(i=0; i<C; i++){
var[i]=0
  }

  for (i=0; i<N; i++){
    for(i=0; i<C; i++){
var[i]++
    }
  }

  for(i=0; i<C; i++){
    if(var[i]!=100){
fmt.Printf("%d\n",var[i])
    }
  }


}
