#!/usr/bin/env python3
"""
Script to fix C-to-Go translation issues in DataRaceBench files.
This script handles more complex transformations that are difficult with shell scripts.
"""

import re
import os
import glob
import subprocess

def fix_file(filepath):
    """Fix a single Go file with common C-to-Go translation issues."""
    print(f"Processing {filepath}...")
    
    try:
        with open(filepath, 'r') as f:
            content = f.read()
        
        # Step 1: Fix license header structure
        # Find the end of the license header (before the actual code)
        license_end_pattern = r'(\*/\s*(?:/\*[^*]*\*/)?\s*(?:int main|func main|var main|#include))'
        
        # Extract license header and code separately
        parts = content.split('package main', 1)
        if len(parts) == 2:
            license_part = parts[0]
            code_part = parts[1]
            
            # Clean up license part - ensure it's properly commented
            license_part = license_part.strip()
            if not license_part.startswith('/*'):
                license_part = '/*\n' + license_part
            if not license_part.endswith('*/'):
                license_part = license_part + '\n*/'
            
            # Start building the new content
            new_content = license_part + '\n\n'
            new_content += 'package main\n\n'
            new_content += 'import (\n'
            new_content += '    "fmt"\n'
            new_content += '    "sync"\n'
            new_content += ')\n\n'
            
            # Process the code part
            code_part = code_part.strip()
            
            # Remove any leftover license text that's not in comments
            code_part = re.sub(r'^[^/]*?Redistribution and use.*?SOFTWARE\.', '', code_part, flags=re.DOTALL)
            code_part = re.sub(r'^\s*\*/\s*', '', code_part)
            
            # Fix common C-to-Go patterns
            code_part = fix_code_patterns(code_part)
            
            new_content += code_part
        else:
            # No package main found, just fix the existing content
            new_content = fix_code_patterns(content)
        
        # Write the fixed content
        with open(filepath, 'w') as f:
            f.write(new_content)
        
        return True
        
    except Exception as e:
        print(f"Error processing {filepath}: {e}")
        return False

def fix_code_patterns(code):
    """Fix common C-to-Go code patterns."""
    
    # Fix main function declarations
    code = re.sub(r'int main\s*\([^)]*\)', 'func main()', code)
    code = re.sub(r'var main\s*\([^)]*\)', 'func main()', code)
    code = re.sub(r'func main\s*\([^)]*\)', 'func main()', code)
    
    # Fix variable declarations
    code = re.sub(r'var\s+(\w+)\s+int\s*=\s*(\d+)', r'var \1 int = \2', code)
    code = re.sub(r'var\s+(\w+)\s+float64\s*=\s*([0-9.]+)', r'var \1 float64 = \2', code)
    code = re.sub(r'var\s+(\w+)\s+double\s*=\s*([0-9.]+)', r'var \1 float64 = \2', code)
    
    # Fix for loops - basic pattern
    code = re.sub(r'for\s*\(\s*([^;]*?)\s*;\s*([^;]*?)\s*;\s*([^)]*?)\s*\)', r'for \1; \2; \3', code)
    
    # Fix array declarations
    code = re.sub(r'(\w+)\s*:=\s*make\s*\(\s*\[\s*\]\s*int\s*,\s*(\d+)\s*\)', r'\1 := make([]int, \2)', code)
    
    # Fix printf statements
    code = re.sub(r'printf\s*\(', 'fmt.Printf(', code)
    
    # Remove return 0 from main
    code = re.sub(r'return\s+0\s*;?\s*$', '', code, flags=re.MULTILINE)
    
    # Fix spacing and formatting
    code = re.sub(r'{\s*$', ' {', code, flags=re.MULTILINE)
    code = re.sub(r'}\s*$', '}', code, flags=re.MULTILINE)
    
    # Add WaitGroup usage and suppress unused variable warning
    if 'var wg sync.WaitGroup' in code and '_ = wg' not in code:
        code = re.sub(r'(var wg sync\.WaitGroup)', r'\1\n    _ = wg // Suppress unused variable warning', code)
    
    # Clean up excess whitespace
    code = re.sub(r'\n\s*\n\s*\n', '\n\n', code)
    
    return code

def main():
    """Main function to process all Go files."""
    
    # Get all DRB*.go files
    go_files = glob.glob('DRB*.go')
    
    if not go_files:
        print("No DRB*.go files found in current directory")
        return
    
    print(f"Found {len(go_files)} Go files to process")
    
    success_count = 0
    total_count = len(go_files)
    
    for filepath in go_files:
        if fix_file(filepath):
            success_count += 1
    
    print(f"\nProcessed {success_count}/{total_count} files")
    
    # Test compilation
    print("\nTesting compilation...")
    compile_success = 0
    
    for filepath in go_files:
        try:
            result = subprocess.run(['go', 'build', filepath], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                compile_success += 1
                print(f"✓ {filepath}")
                # Clean up binary
                binary_name = filepath.replace('.go', '')
                if os.path.exists(binary_name):
                    os.remove(binary_name)
            else:
                print(f"✗ {filepath}: {result.stderr.strip()}")
        except Exception as e:
            print(f"✗ {filepath}: Error running go build: {e}")
    
    print(f"\nCompilation summary: {compile_success}/{total_count} files compile successfully")

if __name__ == "__main__":
    main() 